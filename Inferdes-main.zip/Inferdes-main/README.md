# Sou professor Jean.
Professor de Pensamento Computacional; professor de Programação Tecnológica e Computacional; professor de Programação e Games do Programa Edutech-Pr.

### Olá amigos da programação 👋

** Vamos compartilhar nossas afinides e nossos anceios?**

** Minhas redes sociais e proficionais estão te esperando:**

<a href="https://www.instagram.com/inferdes/">
  <img align="left" alt="Abhishek's Instagram" width="22px" src="https://raw.githubusercontent.com/hussainweb/hussainweb/main/icons/instagram.png" />
  </a>
<a href="https://www.linkedin.com/in/jean-carlos-inferdes-bb3852102/">
  <img align="left" alt="Abhishek's LinkedIN" width="22px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/linkedin.svg" />
</a>
<a href="https://www.facebook.com/jeaninferdes/">
  <img align="left" alt="Abhishek's Facebook" width="95px" src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" />

</a>


<!--
**Inferdes/Inferdes** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
